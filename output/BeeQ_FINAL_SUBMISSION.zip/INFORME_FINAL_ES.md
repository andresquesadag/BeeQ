# BeeQ: versión completa revisada y entrega científica

Base editorial: el PDF de ocho páginas suministrado y los dos reviews originales.
Productos: manuscrito completo en inglés (8 páginas), suplemento integrado
(8 páginas), respuesta en inglés (3 páginas) y fuentes LaTeX editables.

## Diagnóstico y evidencia

El MLP original omitió pesos por muestra. El commit
`5a410041c9807aa499e8cf3f64bd855f21d51558` lo introdujo así; no contiene una
justificación contemporánea. La versión registrada, scikit-learn 1.9.0, admite
`sample_weight`, por lo que una restricción de esa versión no es una causa
demostrada. La intención de los autores continúa indeterminada. El diagnóstico
previo a la implementación está en `docs/MLP_BALANCING_DIAGNOSIS.md`.

Se mantuvieron X10, moléculas, cinco folds externos y cuatro internos por
clusters. LR usa `balanced`, RF `balanced_subsample` y los tres SVC `balanced`.
El MLP original no usa ponderación ni remuestreo. Su versión balanceada pasa
pesos `N_fit/(2*n_clase_fit)` sólo al entrenamiento; escalado y evaluación siguen
sin pesos. No intervienen etiquetas de evaluación, holdout ni CR8. Se conserva
el comportamiento nativo: ponderación de la exactitud de early stopping y
normalización de gradiente/regularización por suma de pesos del minibatch.

La reserva nativa de early stopping es por moléculas y comparte 14-32 clusters
con el entrenamiento por gradiente. El escalador utiliza la partición CV de
entrenamiento completa, incluida esa reserva, y excluye el fold de evaluación.
Se declara esta limitación; modificarla sólo para una variante habría impedido
atribuir el contraste al balanceo bajo el protocolo original.

## Implementación y validación efectivas

La ejecución pequeña precedió a dos ejecuciones completas independientes. El
runner adicional es `src/mlp_sensitivity.py`; el auditor independiente,
`src/mlp_sensitivity_report.py`. El original se reprodujo con diferencia máxima
de score de 1.89e-15, frente a tolerancia 1e-10. La ejecución autoritativa está en
`results/mlp_sensitivity/full_20261009_v2`. Contiene 693 fits, 0 advertencias
capturadas y parada antes de 2000 iteraciones (12-77). Esto verifica el criterio
configurado, no un óptimo global. Los 18 CSV del rerun coinciden exactamente.
Las comprobaciones completas y los 19 tests aprobados están documentados en
`docs/mlp_sensitivity/VALIDATION.json` y `VALIDATION_COMMANDS.md`.

El análisis A fija las configuraciones seleccionadas originalmente en cada fold
y en el fit final. El B repite el espacio original de 12 candidatos y presupuesto
anidado, con selección por AUROC interno medio sin pesos. Cada variante estima
su umbral desde OOF de entrenamiento: MCC máximo, BA máxima, menor umbral
absoluto y menor valor. Para el modelo final, selección y umbral utilizan los
cinco folds congelados de Development. Las decisiones preceden a las nuevas
predicciones externas; ambas evaluaciones añadidas son retrospectivas.

Los otros cinco modelos reutilizan resultados cuya procedencia y métricas se
verificaron; no se reentrenaron. En esta etapa editorial tampoco se entrenó un
predictor: se reconstruyeron tablas, figuras, geometría y dominios desde los
artefactos compatibles. `audit/EDITORIAL_VALIDATION.json` registra diez controles
adicionales, incluidos hashes, métricas independientes, agregaciones, redondeos
y texto de los PDFs; `audit/BUILD_CHECK.json` y `VISUAL_QA.json` registran la
compilación y revisión de todas las páginas.

## Resultados comparativos

Development: media ± desviación estándar muestral de los cinco folds externos;
BA y MCC corresponden a las decisiones OOF anidadas agrupadas, cada fold con su
umbral interno. No se confunden con las métricas OOF de selección final.

| Variante | AUROC | AUPRC | BA agrupada | MCC agrupado | TP/FN/TN/FP agrupados |
|---|---:|---:|---:|---:|---|
| Original | 0.6771 ± 0.1245 | 0.5961 ± 0.1383 | 0.6536 | 0.4283 | 75/147/475/15 |
| Balanceado A, parámetros fijos | 0.6884 ± 0.1005 | 0.6086 ± 0.1186 | 0.6381 | 0.3442 | 79/143/451/39 |
| Balanceado B, búsqueda completa | 0.6792 ± 0.0997 | 0.5942 ± 0.1119 | 0.6322 | 0.3376 | 75/147/454/36 |

Las diferencias emparejadas medias de AUROC son +0.0113 en A y +0.0021 en B.
La sensibilidad mejora en cuatro folds, pero cae de 12/37 a 1/37 en el tercero.
El bootstrap por clusters condiciona sobre predicciones agrupadas: sus intervalos
de AUROC incluyen cero en ambos contrastes; no refleja incertidumbre por refit o
selección ni ajusta multiplicidad. La AUPRC agrupada de B disminuye 0.0474, con
intervalo descriptivo [-0.0989,-0.0009]; este estimando difiere de la media de
los cinco folds. No hay una mejora general de discriminación.

Holdout histórico: 49 tóxicos y 132 no tóxicos. Umbrales congelados por separado.

| Variante | AUROC/AUPRC | Sensibilidad | Especificidad | TP/FN/TN/FP | Umbral |
|---|---:|---:|---:|---|---:|
| Original | 0.4624/0.3024 | 0.0816 | 0.9697 | 4/45/128/4 | 0.524583 |
| Balanceado A | 0.4814/0.3321 | 0.2245 | 0.8788 | 11/38/116/16 | 0.536224 |
| Balanceado B | 0.4821/0.3290 | 0.2653 | 0.8333 | 13/36/110/22 | 0.528334 |

En CR8, ambas variantes recuperan Isocycloseram, siguen fallando Ethiprole y
añaden un falso positivo de Fluoxapiprolin; Florylpicoxamid continúa siendo falso
positivo. AUROC/AUPRC caen de 0.833/0.583 a 0.667/0.450 en A y 0.583/0.367 en B.
Los ocho scores y decisiones están en M5 y en `EXTERNAL_PREDICTIONS.csv`. Dos
positivos no permiten inferir sensibilidad poblacional o desempeño regional.

Configuración final original y A: capas (32,16), alpha=0.01, rate=0.0003. B:
capas (32,16), alpha=0.001, rate=0.001. Las configuraciones de cada fold, sus
umbrales, distribución de clases y convergencia figuran en M3-M4-M7 y los CSV.

## Respuestas científicas explícitas

1. **¿Por qué no estaba balanceado?** Se confirma la omisión; no se determina
   la intención. La versión soporta ponderación, por lo que esa restricción no
   explica el caso.
2. **¿Explica parte del desempeño inferior?** Afecta las decisiones y la
   recuperación retrospectiva; no demuestra que explique su menor discriminación
   global o su brecha de transferencia.
3. **¿Mejora consistentemente la sensibilidad?** No en Development; mejora en
   cuatro folds y empeora marcadamente en uno. Aumenta en este holdout.
4. **¿Cambia discriminación o decisiones?** El cambio mayor está en decisiones
   al umbral. Scores y umbrales cambian juntos, por lo que no se atribuye todo
   a desplazar el umbral. AUROC permanece cercana a 0.48 en holdout y la
   discriminación CR8 empeora.
5. **¿Costo en especificidad?** Holdout: 0.970 a 0.879/0.833 y FP 4 a 16/22.
   Development también añade FP y reduce MCC agrupado.
6. **¿Cambian las conclusiones centrales?** Se mantiene la ausencia de ventaja
   predictiva persistente de los kernels cuánticos frente a RBF bajo X10.
   Se matiza el resultado original del MLP y se corrige la afirmación de que
   todas las variantes fallan ambos tóxicos CR8. No se valida un screening.
7. **¿Qué incertidumbres quedan?** Intención original, atribución causal a X10,
   stopping no agrupado, exposición histórica y precisión mínima de CR8.
   Permanecen ausentes la ampliación de representación y una evaluación nueva
   prospectiva; no se afirma haberlas realizado.

## Cambios editoriales y fuentes

La revisión reconstruye el manuscrito completo, no sólo bloques de reemplazo.
Methods II-C-D-E documenta original, pesos, análisis A/B, umbrales y retrospectiva.
Results III-B-C-E incorpora Development, holdout y CR8. Tabla II compara MLP;
III integra holdout; IV contextualiza resultados publicados de ApisTox con
cohortes/particiones no comparables y AUPRC no reportada. Abstract y Conclusions
dan relevancia a la recuperación tóxica. III-D vincula la geometría con teoría
sin equiparar CKA elevada a concentración exponencial demostrada y cita
bandwidth, projected kernels y entrenamiento por alineación como alternativas
no probadas. El suplemento incorpora D1-D7 originales y M1-M7 adicionales.

Correcciones verificadas del PDF: rango AUROC holdout 0.462-0.706 incluyendo MLP;
asignación RBF/Product/IQP 0.706/0.697/0.696; SD MLP 0.124 a tres decimales; CKA
Product-IQP 0.999506; Product sin capa entrelazante; ecuaciones definidas; retirada
de duplicaciones y marcadores irresueltos. Se verificaron enlaces primarios de
ApisTox, adaptación de kernels, Ethiprole, registro SFE y evaluación MAFF.
`audit/SOURCE_LEDGER.md` contiene fuentes, fechas y límites de procedencia.

La respuesta punto por punto en inglés está en `RESPONSE_TO_REVIEWERS.tex` y su
PDF. Reconoce explícitamente que la recomendación X15/X20/fingerprints del
Reviewer 2 no se ejecutó. No presenta esa recomendación como satisfecha por una
discusión bibliográfica.

## Reproducibilidad y pendientes

`README.md` de este directorio contiene comandos exactos de reconstrucción
editorial y repetición del experimento, versiones, semillas y rutas. Se
compilaron los tres documentos con TinyTeX ya instalado: dos pasadas, cero
advertencias LaTeX, referencias resueltas y ninguna caja desbordada. El compilador
nativo se intentó y falló por resolución de directorios del host, no por el
documento; la compilación alternativa fue exitosa.

No quedan ejecuciones pendientes para la comparación de balanceo definida.
Sí permanecen la ablación de representación fuera del alcance, la identidad
editorial de autores/afiliaciones (el PDF tiene placeholders), la instantánea
original fechada de selección CR8 y la procedencia completa de curation y
generación de los dos descriptores in-house. Se separan estos límites de la
reproducibilidad efectiva de los modelos sobre tablas X10 congeladas.
