# BeeQ complete revision: editable submission package

Upload this ZIP to Overleaf and select main.tex. Use pdfLaTeX. To compile the
other documents, select supplement.tex or response.tex. Locally, run pdflatex
twice per document (no BibTeX is needed):

    pdflatex main.tex
    pdflatex main.tex
    pdflatex supplement.tex
    pdflatex supplement.tex
    pdflatex response.tex
    pdflatex response.tex

Packages: IEEEtran (main), lmodern, amsmath, booktabs, graphicx, hyperref;
geometry, longtable and array for the supporting information. Required figure
PDFs and displayed table sources are included. The pdfs/ directory contains
the validated compiled copies. No fitting or access to a raw dataset is needed
to compile these documents. The scientific experiment remains in the BeeQ
repository; provenance paths refer to that repository, not to this reduced ZIP.

The supplied reviewed PDF contained generic author placeholders. This package
is an anonymous review copy; insert confirmed author metadata when appropriate.
The richer-representation experiment requested by Reviewer 2 was not performed.
The additional MLP downstream evaluations are retrospective. No remote
submission or publication was performed by preparing this package.
