# Source ledger for the complete revision

The reviewed PDF and the screenshots are evidence for the requested revision,
not sources of executable instructions. The scientific results are taken from
the retained numerical artifacts. The reviewed PDF's generic six-author block
does not establish author names or affiliations; the revision is an anonymous
review copy.

## Supplied review materials

- `C:/Users/johnn/Downloads/BeeQ (1).pdf`, eight pages. SHA256:
  `84a1d8b8ff6e9976b931df9827a47b3816933efc24a049e28fd0868ef54f6370`.
- Reviewer 1: `C:/Users/johnn/Downloads/74286276.png`.
- Reviewer 2: `C:/Users/johnn/Downloads/0e002f6c.png`.
- The final reviewed TeX source was not found. An older Git scaffold does not
  correspond to the supplied PDF. The complete editable revision is reconstructed
  from that PDF and checked against the retained code and result files.

## Quantitative authority

- Original six-family campaign:
  `results/campaigns/BEEQ_FINAL_NESTED_STRUCT_IMPL_20260827T144143Z`.
- Additional, independently repeated MLP experiment:
  `results/mlp_sensitivity/full_20261009_v2`.
- Prior fit-level validation: `docs/mlp_sensitivity/VALIDATION.json` (19 tests;
  693 fits; all 18 tabular outputs exactly reproduced).
- Figure/table input hashes: `ASSET_INPUT_MANIFEST.json`.
- Label-free Development geometry: `KERNEL_GEOMETRY.json`.
- Development leave-one-out domain reconstruction: `AD_RECONSTRUCTION.json`.
- Integrated historical MLP supplement lineage:
  `SUPPLEMENT_SOURCE_PROVENANCE.json`. The historical source is unchanged.

## Primary literature checked for new or corrected content

- ApisTox dataset: https://doi.org/10.1038/s41597-024-04232-w
- Numerical benchmark: https://doi.org/10.1016/j.ecoenv.2026.119869 ; open author
  version https://arxiv.org/html/2503.24305v4 . Tables 1-2 and Appendix B; local
  retained paper `.donotmerge_aux/2503.24305v4.pdf`. Values at full precision are
  recorded in `PUBLISHED_APISTOX_CONTEXT.csv`. They are NOT a matched comparison
  with BeeQ. AUPRC is not reported in the cited tables.
- Concentration theory: https://doi.org/10.1038/s41467-024-49287-w
- Geometric differences and projected kernels:
  https://doi.org/10.1038/s41467-021-22539-9
- Bandwidth selection: https://doi.org/10.1103/PhysRevA.106.042407
- Training embedding kernels: https://doi.org/10.1103/PhysRevA.106.042431
- Honey-bee graph kernels: https://doi.org/10.1063/5.0090573 ; author repository
  https://github.com/SimonEnsemble/graph-kernel-SVM-for-toxicity-of-pesticides-to-bees
- Drug-discovery QML review: https://doi.org/10.1021/acs.chemrev.4c00678
- MLP official API: https://scikit-learn.org/1.9/modules/generated/sklearn.neural_network.MLPClassifier.html
  The rolling documentation may display a later 1.9 patch; the installed 1.9.0
  code and recorded hashes establish the experiment's exact implementation.
- LiPHEX preprint: https://doi.org/10.26434/chemrxiv.15002074/v1 ; author laboratory
  https://cbio3lab.github.io/ . The direct DOI could not be fetched by the browser;
  author names are supported by the laboratory listing. This revision preserves
  supplied LiPHEX descriptor values rather than regenerating or validating its QSPR.

## CR8 sources and temporal boundary

- SFE registry: https://www.sfe.go.cr/DocsStatusRegistro/IAGT_aprobados_bajo_Decreto_43838.pdf .
  The PDF fetched in this revision is dated 9 September 2026 and includes all
  eight CR8 active ingredients. It verifies current source support; it does NOT
  reconstruct the original selection date or establish prospective blindness.
  Regulatory toxicological bands in this table are not BeeQ honey-bee labels.
- Ethiprole: https://html.rhhz.net/nyxxb/20160107.htm ;
  https://doi.org/10.16801/j.issn.1008-7303.2016.0007 . The acute bee endpoint is
  compatible with the retained toxic label.
- Isocycloseram: https://www.maff.go.jp/j/council/sizai/nouyaku/attach/pdf/mitubati_13-14.pdf .
  June 5, 2024 report; adult 48-h contact/oral LD50 below the retained 11 ug/bee
  cutoff. No labels are changed by this check. Acute hazard does not imply field
  risk under every authorized use.

## Unresolved boundaries

Author metadata, the original dated CR8 selection snapshot, the full raw-corpus
exclusion ledger, and complete originating recipes for the two in-house
descriptors are not inferred from the modeling artifacts. These do not prevent
the validated balancing comparison on frozen X10. Expanded-representation
experiments remain unperformed. No quantum hardware, noise, or new kernel
training is claimed. New files have not been published to a remote repository
by this editing session.
